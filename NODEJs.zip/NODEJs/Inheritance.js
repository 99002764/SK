class Account{
    constructor(no,name,amount){
        this.no = no
        this.name = name
        this.balance = amount
    }
    credit(amount){
        this.balance += amount;
    }
    debit(amount){
        if(this.balance < amount)
            throw "Insufficient Funds";
        this.balance -= amount;
    }
}
class SBAccount extends Account{
    calcInterest(){
        const principle = this.balance;
        const rateOfInterest = 6.5/100
        const year = 1/4
        const interest = (principle * rateOfInterest * year)
        this.credit(interest)
    }
}
 
try{
    const acc = new SBAccount(123 , "Aditya" , 20000);
    acc.credit(5000)
    acc.debit(5000)
    acc.calcInterest()
    console.log("The Balance " + acc.balance)
}catch(err){
    console.log(err)
}