var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Account = /** @class */ (function () {
    function Account(no, name, balance) {
        this.accNo = no;
        this.accHolder = name;
        this.accBalance = balance;
    }
    Account.prototype.credit = function (amount) {
        this.accBalance += amount;
    };
    Account.prototype.debit = function (amount) {
        if (amount > this.accBalance)
            throw "Insufficient Funds";
        this.accBalance -= amount;
    };
    return Account;
}());
var SBAccount = /** @class */ (function (_super) {
    __extends(SBAccount, _super);
    function SBAccount() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    SBAccount.prototype.calcInterest = function () {
        var r = 6.5 / 100;
        var p = 1 / 4;
        var t = this.accBalance;
        var interest = p * r * t;
        _super.prototype.credit.call(this, interest);
    };
    return SBAccount;
}(Account));
var acc = new SBAccount(123, "Sidhanta", 100000);
acc.credit(50000);
acc.calcInterest();
console.log(acc.accBalance);
