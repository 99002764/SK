function addNumbers(num1, num2) {
    return num1 + num2;
}
var sum = addNumbers(123, 234);
console.log(sum);
