function addNumbers(num1:number , num2:number): number{
    return num1+num2;
}

var sum=addNumbers(123,234);
console.log(sum);

var age:number =43;
var uName: string="Sidhanta";
var currentStatus : boolean=true;

var data=`The name is ${uName} aged ${age}`;
console.log(data);
