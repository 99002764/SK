var elements = [];
elements.push(123);
elements.push(124);
elements.push(125);
elements.push(126);
elements.push(127);
for (var _i = 0, elements_1 = elements; _i < elements_1.length; _i++) {
    var e = elements_1[_i];
    console.log(e);
}
var fruits = Array();
fruits = ["Apple", "Mango", "Orange"];
for (var _a = 0, fruits_1 = fruits; _a < fruits_1.length; _a++) {
    var fruit = fruits_1[_a];
    console.log(fruit);
}
