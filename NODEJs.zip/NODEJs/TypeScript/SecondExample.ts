let elements:number[]=[];
elements.push(123);
elements.push(124);
elements.push(125);
elements.push(126);
elements.push(127);

for(const e of elements){
    console.log(e);
}

let fruits =Array<string>();
fruits=["Apple","Mango","Orange"];
for(const fruit of fruits){
    console.log(fruit);
}

