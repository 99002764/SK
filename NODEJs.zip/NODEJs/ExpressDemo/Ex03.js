const app =require('express')();
const fs= require("fs");
const dir=__dirname;

let employees=[];

function readData(){
    const filename ="data.json";
    const jsonContent = fs.readFileSync(filename, 'utf-8');
    employees=JSON.parse(jsonContent);
}

app.get("/employees",(req,res)=>{
    readData();
    res.send(JSON.stringify(employees));
});
//app.post();
//app.put();
//app.delete();

app.listen(1234, ()=>{
    console.log("Connected to 1234");
})